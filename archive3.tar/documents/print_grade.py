print("Hello!")
a = input()
print(a)
